
package lentokentta.domain;

public class Paikka {
    
    private String tunnus;
    
    
    public Paikka(String tunnus) {
        this.tunnus = tunnus;
    }
    
    public String toString() {
        return this.tunnus;
    }
    
}
